import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const { base64Image, mimeType } = await req.json()

    if (!base64Image) {
      return NextResponse.json({ error: 'No image provided' }, { status: 400 })
    }

    const apiKey = process.env.GEMINI_API_KEY
    if (!apiKey) {
      return NextResponse.json({ error: 'Gemini API key not configured' }, { status: 500 })
    }

    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{
            parts: [
              { inline_data: { mime_type: mimeType || 'image/jpeg', data: base64Image } },
              {
                text: `You are a professional cinematographer and product photographer analyzing an image for AI video/image prompt generation.

Analyze this image and extract ALL visual information with maximum precision.

Return ONLY this JSON (compact, no newlines inside string values):
{
  "subject": "exact description of main subject/product including brand, model if visible",
  "colors": "all dominant colors with approximate hex codes",
  "materials": "all visible materials and their texture qualities",
  "lighting": "light source type, direction (clock position), quality (hard/soft), color temperature (Kelvin), shadows",
  "composition": "framing style, camera angle, depth of field, focal point, rule of thirds placement",
  "mood": "emotional atmosphere, psychological feeling this image conveys",
  "background": "complete background description including color, texture, distance",
  "details": "critical small details that must be preserved: engravings, logos, text, reflections, patterns",
  "style": "overall photographic/visual style (editorial, product, lifestyle, artistic etc)",
  "technical": "estimated focal length, aperture, any visible lens characteristics, image quality"
}

Be hyper-specific. Every detail matters. Return ONLY the JSON object.`
              }
            ]
          }],
          generationConfig: { temperature: 0.1, maxOutputTokens: 1000 }
        })
      }
    )

    const data = await res.json()

    if (data.error) {
      return NextResponse.json({ error: `Gemini: ${data.error.message}` }, { status: 400 })
    }

    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || ''
    const start = text.indexOf('{')
    const end = text.lastIndexOf('}')

    if (start === -1 || end === -1) {
      return NextResponse.json({ error: 'Gemini returned invalid analysis' }, { status: 500 })
    }

    const analysis = JSON.parse(text.slice(start, end + 1))
    return NextResponse.json({ analysis })

  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error'
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
