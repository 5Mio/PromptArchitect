import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const { imageAnalysis, userText, tags, tone, duration, mode } = await req.json()

    const apiKey = process.env.ANTHROPIC_API_KEY
    if (!apiKey) {
      return NextResponse.json({ error: 'Claude API key not configured' }, { status: 500 })
    }

    const context = [
      imageAnalysis && Object.keys(imageAnalysis).length > 0
        ? `IMAGE ANALYSIS (Gemini Vision):\n${JSON.stringify(imageAnalysis, null, 2)}`
        : 'No image provided — work from text intention only.',
      userText ? `USER INTENTION: ${userText}` : '',
      tags?.length ? `STYLE MODIFIERS: ${tags.join(', ')}` : '',
      `TONE: ${tone || 'luxury'}`,
      mode === 'video' ? `DURATION: ${duration || '8'} seconds` : '',
      `OUTPUT MODE: ${(mode || 'video').toUpperCase()} PROMPT`,
    ].filter(Boolean).join('\n\n')

    const system = `You are PromptArchitect Pro — the world's most advanced prompt engineer for AI ${mode || 'video'} generation tools in 2026.

You receive a detailed Gemini Vision image analysis + user creative intention.
Your mission: fuse ALL visual data with the $1M prompt schema into a perfect production-ready prompt.

CRITICAL RULES:
1. Every visual detail from the image analysis MUST appear in the prompt
2. Colors, materials, lighting setup — nothing gets lost
3. World before subject — always describe environment first
4. Physics anchoring — precise physical behavior descriptions
5. Emotional state injection — inner states not performances
6. Anti-stock filter — zero generic commercial aesthetics
7. Intention statement — what viewer FEELS not what they SEE

Return ONLY this compact JSON (no markdown, no explanation, no newlines inside values):
{
  "quality_score": 94,
  "main_prompt": "full structured prompt 200-500 chars",
  "negative_prompt": "specific negatives based on image content",
  "layers": {
    "world": "environment and setting",
    "subject": "subject with emotional state",
    "motion": "camera and subject movement",
    "lighting": "light source behavior and intention",
    "lens": "focal length aperture character",
    "color": "grade and palette",
    "intention": "what viewer should feel"
  },
  "recommended_tool": "single best tool name",
  "ghost_director": "one sentence director philosophy for this scene"
}

All string values max 350 chars. Return ONLY the JSON.`

    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1500,
        system,
        messages: [{ role: 'user', content: context }]
      })
    })

    const data = await res.json()

    if (data.error) {
      return NextResponse.json({ error: `Claude: ${data.error.message}` }, { status: 400 })
    }

    const text = data.content?.map((c: { text?: string }) => c.text || '').join('') || ''
    const start = text.indexOf('{')
    const end = text.lastIndexOf('}')

    if (start === -1 || end === -1) {
      return NextResponse.json({ error: 'Claude returned no valid JSON' }, { status: 500 })
    }

    const result = JSON.parse(text.slice(start, end + 1))
    return NextResponse.json({ result })

  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error'
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
