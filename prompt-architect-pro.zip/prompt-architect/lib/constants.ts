export const LIBRARY = {
  style: [
    'Cinematic', 'Documentary', 'Luxury Commercial', 'Editorial',
    'Noir', 'Hyperrealist', 'Minimalist', 'Vintage 35mm',
    'Futuristic', 'Brutalist',
  ],
  mood: [
    'Intimate', 'Dramatic', 'Melancholic', 'Mysterious',
    'Serene', 'Tense', 'Nostalgic', 'Raw',
    'Triumphant', 'Ethereal',
  ],
  tech: [
    'ARRI Alexa', 'Anamorphic 2.39:1', 'Macro Lens', 'Handheld',
    'Slow Motion', 'Drone Shot', 'Single Light Source',
    'Natural Light', 'Speed Ramp', 'Rack Focus',
  ],
}

export const VIDEO_TOOLS = [
  { name: 'Kling 2.x',     use: 'Organic motion & realism' },
  { name: 'Runway Gen-4',  use: 'Camera movement & transitions' },
  { name: 'Sora',          use: 'Atmospheric & environmental' },
  { name: 'Pika 2.x',      use: 'Product & still-life animation' },
  { name: 'Luma Dream',    use: 'Abstract & stylized looks' },
  { name: 'Haiper',        use: 'Fast-paced dynamic content' },
]

export const IMAGE_TOOLS = [
  { name: 'Midjourney v7',    use: 'Artistic & stylized imagery' },
  { name: 'Flux Pro 1.1',     use: 'Photorealism & product shots' },
  { name: 'DALL-E 3',         use: 'Prompt adherence & concepts' },
  { name: 'Stable Diffusion', use: 'Customization & control' },
  { name: 'Ideogram 2',       use: 'Text-in-image & typography' },
  { name: 'Adobe Firefly',    use: 'Commercial-safe outputs' },
]

export const TONES = [
  ['luxury',      'Luxury / High-End'],
  ['documentary', 'Documentary / Raw'],
  ['editorial',   'Editorial / Fashion'],
  ['dark',        'Dark / Dramatic'],
  ['artistic',    'Artistic / Abstract'],
  ['commercial',  'Commercial / Clean'],
]

export const DURATIONS = [
  ['3',  '3 sec — Micro'],
  ['5',  '5 sec — Standard'],
  ['8',  '8 sec — Hero'],
  ['15', '15 sec — Feature'],
]
