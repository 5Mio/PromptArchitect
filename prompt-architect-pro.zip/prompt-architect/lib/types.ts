export interface GeminiAnalysis {
  subject: string
  colors: string
  materials: string
  lighting: string
  composition: string
  mood: string
  background: string
  details: string
  style: string
  technical: string
}

export interface PromptLayers {
  world: string
  subject: string
  motion: string
  lighting: string
  lens: string
  color: string
  intention: string
}

export interface PromptResult {
  quality_score: number
  main_prompt: string
  negative_prompt: string
  layers: PromptLayers
  recommended_tool: string
  ghost_director: string
}

export type Mode = 'video' | 'image'
export type Step = 0 | 1 | 2 | 3  // idle | gemini | claude | done
export type ActiveTab = 'prompt' | 'layers' | 'tools' | 'analysis'
