import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const { imageBase64, mimeType } = await req.json();

    if (!imageBase64) {
      return NextResponse.json({ error: "No image provided" }, { status: 400 });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json({ error: "Gemini API key not configured" }, { status: 500 });
    }

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{
            parts: [
              {
                inline_data: {
                  mime_type: mimeType || "image/jpeg",
                  data: imageBase64,
                },
              },
              {
                text: `You are a professional cinematographer and product photographer analyzing an image for AI video/image prompt generation.

Analyze this image and extract ALL visual information. Return ONLY this JSON (compact, no newlines inside string values):

{
  "subject": "main subject or product with precise description",
  "colors": "all dominant colors with approximate hex codes",
  "materials": "visible materials and surface textures",
  "lighting": "light source type, direction angle, quality soft/hard, color temperature",
  "composition": "framing, camera angle, depth of field, focal point position",
  "mood": "emotional atmosphere and psychological feeling",
  "background": "background elements and treatment",
  "details": "critical small details that must be preserved",
  "style": "overall visual aesthetic and style",
  "technical": "photography/cinematography aspects like lens compression, exposure"
}

Be hyper-specific. Every detail matters for prompt generation. Return ONLY the JSON object.`,
              },
            ],
          }],
          generationConfig: {
            temperature: 0.1,
            maxOutputTokens: 1000,
          },
        }),
      }
    );

    const data = await response.json();

    if (data.error) {
      return NextResponse.json({ error: `Gemini: ${data.error.message}` }, { status: 400 });
    }

    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
    const start = text.indexOf("{");
    const end = text.lastIndexOf("}");

    if (start === -1 || end === -1) {
      return NextResponse.json({ error: "Gemini returned no valid JSON" }, { status: 500 });
    }

    const analysis = JSON.parse(text.slice(start, end + 1));
    return NextResponse.json({ analysis });

  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
