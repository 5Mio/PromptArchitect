import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const { imageAnalysis, userText, tags, tone, duration, mode } = await req.json();

    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      return NextResponse.json({ error: "Anthropic API key not configured" }, { status: 500 });
    }

    const context = [
      imageAnalysis && Object.keys(imageAnalysis).length > 0
        ? `IMAGE ANALYSIS (Gemini Vision):\n${JSON.stringify(imageAnalysis, null, 2)}`
        : null,
      userText ? `USER INTENTION: ${userText}` : null,
      tags?.length ? `STYLE MODIFIERS: ${tags.join(", ")}` : null,
      `TONE: ${tone || "luxury"}`,
      mode === "video" ? `DURATION: ${duration || "8"} seconds` : null,
      `OUTPUT MODE: ${(mode || "video").toUpperCase()} PROMPT`,
    ].filter(Boolean).join("\n\n");

    const system = `You are PromptArchitect Pro — elite prompt engineer for ${mode} generation tools 2026.

You receive detailed image analysis from Gemini Vision plus user creative intention.
Fuse ALL visual data with user intention into a PERFECT production-ready prompt.

CRITICAL RULES:
- Every color, material, lighting detail from image analysis MUST appear in the prompt
- World before subject — describe environment first
- Physics anchoring — precise physical behavior descriptions
- Emotional state injection — inner state not performance
- Anti-stock filter — no generic commercial look
- Intention statement — what viewer FEELS not what they SEE

Return ONLY this compact JSON (no markdown, no newlines inside string values):
{"quality_score":92,"main_prompt":"...","negative_prompt":"...","layers":{"world":"...","subject":"...","motion":"...","lighting":"...","lens":"...","color":"...","intention":"..."},"recommended_tool":"...","ghost_director":"..."}

Requirements:
- main_prompt: 200-500 chars, hyper-specific using ALL image data
- negative_prompt: specific to image content and common AI failures
- Each layer value max 300 chars, no newlines
- ghost_director: one sentence invisible director philosophy
- recommended_tool: single best tool name for this content`;

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1500,
        system,
        messages: [{ role: "user", content: context }],
      }),
    });

    const data = await response.json();

    if (data.error) {
      return NextResponse.json({ error: `Claude: ${data.error.message}` }, { status: 400 });
    }

    const text = data.content?.map((c: any) => c.text || "").join("") || "";
    const start = text.indexOf("{");
    const end = text.lastIndexOf("}");

    if (start === -1 || end === -1) {
      return NextResponse.json({ error: "Claude returned no valid JSON" }, { status: 500 });
    }

    const prompt = JSON.parse(text.slice(start, end + 1));
    return NextResponse.json({ prompt });

  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
