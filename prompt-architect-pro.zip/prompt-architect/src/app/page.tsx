"use client";

import { useState, useRef, useCallback } from "react";
import {
  LIBRARY, VIDEO_TOOLS, IMAGE_TOOLS,
  type Mode, type Step, type GeminiAnalysis, type PromptOutput,
} from "@/lib/constants";

// ─── Small UI Components ───────────────────────────────────────

function Tag({ label, type, selected, onClick }: {
  label: string; type: string; selected: boolean; onClick: () => void;
}) {
  const p: Record<string, { a: string; bg: string; dim: string; border: string }> = {
    style: { a: "#ff4d00", bg: "rgba(255,77,0,0.18)", dim: "rgba(255,77,0,0.05)", border: "rgba(255,77,0,0.22)" },
    mood:  { a: "#ffd166", bg: "rgba(255,209,102,0.18)", dim: "rgba(255,209,102,0.05)", border: "rgba(255,209,102,0.22)" },
    tech:  { a: "#4ade80", bg: "rgba(74,222,128,0.18)", dim: "rgba(74,222,128,0.05)", border: "rgba(74,222,128,0.22)" },
  };
  const c = p[type];
  return (
    <button onClick={onClick} style={{
      padding: "4px 11px", borderRadius: 20, fontSize: 11,
      fontFamily: "var(--font-mono)", cursor: "pointer", letterSpacing: "0.3px",
      border: `1px solid ${selected ? c.a : c.border}`,
      background: selected ? c.bg : c.dim,
      color: selected ? c.a : "#555",
      transition: "all 0.15s",
    }}>{label}</button>
  );
}

function SectionLabel({ color, children }: { color: string; children: string }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
      <span style={{
        fontSize: 9, fontWeight: 700, letterSpacing: 2.5, padding: "3px 10px",
        background: `${color}18`, color, borderRadius: 2,
        fontFamily: "var(--font-mono)", textTransform: "uppercase" as const,
      }}>{children}</span>
      <div style={{ flex: 1, height: 1, background: "var(--border)" }} />
    </div>
  );
}

function PromptBox({ content, borderColor, textColor }: {
  content: string; borderColor: string; textColor?: string;
}) {
  return (
    <div style={{
      background: "var(--surface)", border: "1px solid var(--border2)",
      borderLeft: `3px solid ${borderColor}`, borderRadius: 8,
      padding: "14px 16px", fontFamily: "var(--font-mono)",
      fontSize: 12.5, lineHeight: 1.9, color: textColor || "#c8c4be",
      whiteSpace: "pre-wrap", wordBreak: "break-word",
    }}>{content}</div>
  );
}

function StepBadge({ num, label, status }: { num: string; label: string; status: "idle" | "active" | "done" }) {
  const c = { idle: "#2a2a2a", active: "#ff4d00", done: "#4ade80" }[status];
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
      <div style={{
        width: 20, height: 20, borderRadius: "50%", border: `2px solid ${c}`,
        display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: 9, fontWeight: 700, color: c, fontFamily: "var(--font-mono)",
        background: status === "active" ? "rgba(255,77,0,0.1)" : "transparent",
        transition: "all 0.3s",
      }}>{status === "done" ? "✓" : num}</div>
      <span style={{ fontSize: 10, fontFamily: "var(--font-mono)", color: c, letterSpacing: 1, transition: "color 0.3s" }}>
        {label}
      </span>
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────

export default function Home() {
  const [mode, setMode] = useState<Mode>("video");
  const [text, setText] = useState("");
  const [tags, setTags] = useState<string[]>([]);
  const [tone, setTone] = useState("luxury");
  const [duration, setDuration] = useState("8");

  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [imageMime, setImageMime] = useState("image/jpeg");

  const [step, setStep] = useState<Step>(0);
  const [geminiAnalysis, setGeminiAnalysis] = useState<GeminiAnalysis | null>(null);
  const [output, setOutput] = useState<PromptOutput | null>(null);
  const [error, setError] = useState("");
  const [activeTab, setActiveTab] = useState("prompt");
  const [copied, setCopied] = useState(false);

  const fileRef = useRef<HTMLInputElement>(null);

  const toggleTag = (t: string) =>
    setTags(p => p.includes(t) ? p.filter(x => x !== t) : [...p, t]);

  const handleFile = useCallback((file: File) => {
    if (!file || !file.type.startsWith("image/")) return;
    setImageMime(file.type);
    const reader = new FileReader();
    reader.onload = e => {
      const result = e.target?.result as string;
      setImagePreview(result);
      setImageBase64(result.split(",")[1]);
    };
    reader.readAsDataURL(file);
  }, []);

  const generate = async () => {
    if (!imageBase64 && !text.trim()) return;
    setError("");
    setOutput(null);
    setGeminiAnalysis(null);

    try {
      let analysis: GeminiAnalysis | null = null;

      // STEP 1: Gemini Vision Analysis
      if (imageBase64) {
        setStep(1);
        const res = await fetch("/api/analyze", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ imageBase64, mimeType: imageMime }),
        });
        const data = await res.json();
        if (data.error) throw new Error(data.error);
        analysis = data.analysis;
        setGeminiAnalysis(analysis);
      }

      // STEP 2: Claude Prompt Builder
      setStep(2);
      const res = await fetch("/api/build-prompt", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ imageAnalysis: analysis || {}, userText: text, tags, tone, duration, mode }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);

      setOutput(data.prompt);
      setStep(3);
      setActiveTab("prompt");
    } catch (e: any) {
      setError(e.message);
      setStep(0);
    }
  };

  const copyAll = () => {
    if (!output) return;
    navigator.clipboard.writeText(`MAIN PROMPT:\n${output.main_prompt}\n\nNEGATIVE PROMPT:\n${output.negative_prompt}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const tools = mode === "video" ? VIDEO_TOOLS : IMAGE_TOOLS;
  const qScore = output?.quality_score || 0;
  const qColor = qScore >= 90 ? "#4ade80" : qScore >= 80 ? "#ffd166" : "#ff6464";
  const isLoading = step === 1 || step === 2;
  const canGenerate = (!!imageBase64 || !!text.trim()) && !isLoading;

  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>

      {/* ── HEADER ── */}
      <header style={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "14px 28px", borderBottom: "1px solid var(--border)",
        background: "rgba(8,8,8,0.97)", backdropFilter: "blur(20px)",
        position: "sticky", top: 0, zIndex: 50,
      }}>
        <div style={{ display: "flex", alignItems: "baseline", gap: 10 }}>
          <span style={{ fontSize: 17, fontWeight: 800, letterSpacing: -0.5 }}>PromptArchitect</span>
          <span style={{
            fontSize: 9, fontWeight: 700, letterSpacing: 3, color: "var(--accent)",
            padding: "3px 8px", border: "1px solid var(--accent)", borderRadius: 2,
          }}>PRO v3</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          {/* Pipeline Status */}
          <div style={{
            display: "flex", alignItems: "center", gap: 14,
            padding: "7px 16px", background: "var(--surface)", borderRadius: 6, border: "1px solid var(--border)",
          }}>
            <StepBadge num="1" label="Gemini Vision" status={step === 0 ? "idle" : step === 1 ? "active" : "done"} />
            <div style={{ width: 20, height: 1, background: "var(--border2)" }} />
            <StepBadge num="2" label="Claude Architect" status={step < 2 ? "idle" : step === 2 ? "active" : "done"} />
          </div>
          {/* Mode Toggle */}
          <div style={{ display: "flex", background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 6, padding: 3, gap: 2 }}>
            {(["video", "image"] as Mode[]).map(m => (
              <button key={m} onClick={() => setMode(m)} style={{
                padding: "6px 16px", fontSize: 11, fontWeight: 700, letterSpacing: 1,
                textTransform: "uppercase", border: "none", borderRadius: 4, cursor: "pointer",
                fontFamily: "var(--font-display)", transition: "all 0.2s",
                background: mode === m ? (m === "video" ? "var(--accent)" : "var(--gold)") : "transparent",
                color: mode === m ? (m === "video" ? "white" : "#000") : "var(--text-muted)",
              }}>{m === "video" ? "▶ Video" : "◼ Image"}</button>
            ))}
          </div>
        </div>
      </header>

      {/* ── BODY ── */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", flex: 1, minHeight: "calc(100vh - 57px)" }}>

        {/* ── LEFT: INPUT ── */}
        <div style={{ borderRight: "1px solid var(--border)", display: "flex", flexDirection: "column" }}>
          <div style={{ flex: 1, overflowY: "auto", padding: "22px 26px", display: "flex", flexDirection: "column", gap: 20 }}>

            {/* IMAGE UPLOAD */}
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
                <span style={{ width: 6, height: 6, borderRadius: "50%", background: "var(--gold)", display: "inline-block" }} />
                <span style={{ fontSize: 10, letterSpacing: 2.5, textTransform: "uppercase", color: "var(--text-muted)", fontFamily: "var(--font-mono)" }}>
                  Image Input <span style={{ color: "var(--accent)" }}>— Gemini will analyze</span>
                </span>
              </div>

              {imagePreview ? (
                <div style={{ position: "relative", borderRadius: 10, overflow: "hidden", border: "1px solid var(--accent)" }}>
                  <img src={imagePreview} alt="ref" style={{ width: "100%", height: 220, objectFit: "cover", display: "block" }} />
                  <div style={{
                    position: "absolute", bottom: 0, left: 0, right: 0,
                    background: "linear-gradient(transparent, rgba(0,0,0,0.88))",
                    padding: "20px 14px 12px",
                    display: "flex", justifyContent: "space-between", alignItems: "center",
                  }}>
                    <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--gold)" }}>
                      {geminiAnalysis ? "✓ Gemini analysis complete" : "Ready for Gemini analysis"}
                    </span>
                    <button onClick={() => { setImagePreview(null); setImageBase64(null); setGeminiAnalysis(null); }} style={{
                      background: "rgba(0,0,0,0.6)", border: "1px solid #333", color: "#aaa",
                      width: 26, height: 26, borderRadius: "50%", cursor: "pointer", fontSize: 14,
                    }}>×</button>
                  </div>
                </div>
              ) : (
                <div
                  onClick={() => fileRef.current?.click()}
                  onDrop={e => { e.preventDefault(); handleFile(e.dataTransfer.files[0]); }}
                  onDragOver={e => e.preventDefault()}
                  style={{
                    border: "1.5px dashed var(--border2)", borderRadius: 10, padding: "36px 20px",
                    textAlign: "center", cursor: "pointer", background: "var(--surface)",
                    transition: "all 0.2s",
                  }}
                  onMouseEnter={e => { (e.currentTarget as HTMLDivElement).style.borderColor = "var(--accent)"; (e.currentTarget as HTMLDivElement).style.background = "rgba(255,77,0,0.04)"; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.borderColor = "var(--border2)"; (e.currentTarget as HTMLDivElement).style.background = "var(--surface)"; }}
                >
                  <div style={{ fontSize: 30, opacity: 0.15, marginBottom: 12 }}>⬆</div>
                  <div style={{ fontFamily: "var(--font-mono)", fontSize: 12, color: "var(--accent)", marginBottom: 6 }}>
                    Upload Product / Reference Image
                  </div>
                  <div style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--text-dim)", lineHeight: 1.7 }}>
                    Drag & drop or click to browse<br />
                    Gemini Flash extracts all visual data automatically
                  </div>
                </div>
              )}
              <input ref={fileRef} type="file" accept="image/*" style={{ display: "none" }}
                onChange={e => e.target.files?.[0] && handleFile(e.target.files[0])} />
            </div>

            {/* GEMINI ANALYSIS PREVIEW */}
            {geminiAnalysis && (
              <div style={{
                background: "rgba(66,133,244,0.04)", border: "1px solid rgba(66,133,244,0.15)",
                borderRadius: 8, padding: "14px", animation: "fadeUp 0.3s ease",
              }}>
                <div style={{ fontFamily: "var(--font-mono)", fontSize: 9, letterSpacing: 2.5, textTransform: "uppercase", color: "var(--blue)", marginBottom: 12 }}>
                  ✓ Gemini Vision Analysis
                </div>
                {Object.entries(geminiAnalysis).slice(0, 6).map(([k, v]) => (
                  <div key={k} style={{ display: "grid", gridTemplateColumns: "90px 1fr", gap: 8, marginBottom: 6 }}>
                    <span style={{ fontFamily: "var(--font-mono)", fontSize: 9, color: "var(--blue)", textTransform: "uppercase", letterSpacing: 1, paddingTop: 2 }}>{k}</span>
                    <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "#777", lineHeight: 1.5 }}>
                      {String(v).slice(0, 100)}{String(v).length > 100 ? "…" : ""}
                    </span>
                  </div>
                ))}
              </div>
            )}

            {/* TEXT INPUT */}
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
                <span style={{ width: 6, height: 6, borderRadius: "50%", background: "var(--accent)", display: "inline-block" }} />
                <span style={{ fontSize: 10, letterSpacing: 2.5, textTransform: "uppercase", color: "var(--text-muted)", fontFamily: "var(--font-mono)" }}>
                  Additional Intention <span style={{ color: "var(--text-dim)" }}>(optional)</span>
                </span>
              </div>
              <textarea
                rows={3} value={text} onChange={e => setText(e.target.value)}
                placeholder="e.g. Focus on the craftsmanship, dark luxury atmosphere, mysterious feeling..."
                style={{
                  width: "100%", background: "var(--surface)", border: "1px solid var(--border2)",
                  borderRadius: 8, color: "#c8c4be", fontSize: 12.5, lineHeight: 1.8,
                  padding: "12px 14px", resize: "none", transition: "all 0.2s",
                }}
              />
            </div>

            {/* SETTINGS */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              {[
                {
                  label: "Tone", val: tone, set: setTone,
                  opts: [["luxury","Luxury / High-End"],["documentary","Documentary / Raw"],["editorial","Editorial / Fashion"],["dark","Dark / Dramatic"],["artistic","Artistic / Abstract"],["commercial","Commercial / Clean"]],
                },
                ...(mode === "video" ? [{
                  label: "Duration", val: duration, set: setDuration,
                  opts: [["3","3 sec — Micro"],["5","5 sec — Standard"],["8","8 sec — Hero"],["15","15 sec — Feature"]],
                }] : []),
              ].map(({ label, val, set, opts }) => (
                <div key={label}>
                  <div style={{ fontSize: 9, letterSpacing: 2.5, textTransform: "uppercase", color: "var(--text-dim)", marginBottom: 7, fontFamily: "var(--font-mono)" }}>{label}</div>
                  <div style={{ position: "relative" }}>
                    <select value={val} onChange={e => (set as (v: string) => void)(e.target.value)} style={{
                      width: "100%", appearance: "none", background: "var(--surface)",
                      border: "1px solid var(--border2)", borderRadius: 6, color: "#c8c4be",
                      fontSize: 11, padding: "9px 28px 9px 12px", cursor: "pointer", transition: "border-color 0.2s",
                    }}>
                      {opts.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
                    </select>
                    <span style={{ position: "absolute", right: 10, top: "50%", transform: "translateY(-50%)", color: "var(--text-dim)", fontSize: 10, pointerEvents: "none" }}>▾</span>
                  </div>
                </div>
              ))}
            </div>

            {/* ORCHESTRA */}
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
                <span style={{ fontSize: 9, letterSpacing: 2.5, textTransform: "uppercase", color: "var(--text-dim)", fontFamily: "var(--font-mono)", whiteSpace: "nowrap" }}>Orchestra Library</span>
                <div style={{ flex: 1, height: 1, background: "var(--border)" }} />
                {tags.length > 0 && (
                  <button onClick={() => setTags([])} style={{ fontSize: 9, fontFamily: "var(--font-mono)", color: "var(--text-muted)", background: "none", border: "none", cursor: "pointer", letterSpacing: 1 }}>
                    CLEAR {tags.length}
                  </button>
                )}
              </div>
              {Object.entries(LIBRARY).map(([cat, items]) => (
                <div key={cat} style={{ marginBottom: 12 }}>
                  <div style={{ fontSize: 9, letterSpacing: 2, textTransform: "uppercase", color: "#222", marginBottom: 7, fontFamily: "var(--font-mono)" }}>{cat}</div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
                    {items.map(t => <Tag key={t} label={t} type={cat} selected={tags.includes(t)} onClick={() => toggleTag(t)} />)}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* GENERATE */}
          <div style={{ padding: "16px 26px 24px", borderTop: "1px solid var(--border)" }}>
            <button onClick={generate} disabled={!canGenerate} style={{
              width: "100%", padding: "15px 0",
              background: canGenerate ? "var(--accent)" : "var(--surface)",
              border: "none", borderRadius: 8,
              color: canGenerate ? "white" : "var(--text-dim)",
              fontFamily: "var(--font-display)", fontSize: 13, fontWeight: 800,
              letterSpacing: 2, textTransform: "uppercase",
              cursor: canGenerate ? "pointer" : "not-allowed",
              transition: "all 0.2s", position: "relative", overflow: "hidden",
            }}>
              {step === 1 ? <span style={{ animation: "pulse 1.2s infinite" }}>① Gemini Analyzing Image...</span>
               : step === 2 ? <span style={{ animation: "pulse 1.2s infinite" }}>② Claude Building Prompt...</span>
               : `Generate ${mode === "video" ? "Video" : "Image"} Prompt →`}
              {isLoading && (
                <div style={{
                  position: "absolute", bottom: 0, left: "-60%", width: "60%", height: 2,
                  background: step === 1 ? "var(--blue)" : "var(--accent)",
                  animation: "slide 1.4s ease-in-out infinite",
                }} />
              )}
            </button>
            {error && (
              <div style={{
                marginTop: 10, padding: "10px 14px",
                background: "rgba(255,100,100,0.07)", border: "1px solid rgba(255,100,100,0.18)",
                borderRadius: 6, fontFamily: "var(--font-mono)", fontSize: 11, color: "#ff6464", lineHeight: 1.6,
              }}>⚠ {error}</div>
            )}
          </div>
        </div>

        {/* ── RIGHT: OUTPUT ── */}
        <div style={{ background: "#060606", display: "flex", flexDirection: "column" }}>
          <div style={{
            padding: "14px 26px", borderBottom: "1px solid var(--border)",
            display: "flex", alignItems: "center", justifyContent: "space-between",
          }}>
            <div style={{ display: "flex", gap: 2 }}>
              {[["prompt","Prompt"],["layers","Layers"],["tools","Tools"],["analysis","Raw Analysis"]].map(([id, label]) => (
                <button key={id} onClick={() => setActiveTab(id)} style={{
                  padding: "6px 13px", fontSize: 10, fontWeight: 600, letterSpacing: 1.5,
                  textTransform: "uppercase", cursor: "pointer", fontFamily: "var(--font-mono)",
                  border: "none", borderRadius: 5, transition: "all 0.15s",
                  background: activeTab === id ? "var(--surface2)" : "transparent",
                  color: activeTab === id ? "var(--text)" : "var(--text-dim)",
                }}>{label}</button>
              ))}
            </div>
            {output && (
              <button onClick={copyAll} style={{
                padding: "6px 14px", fontSize: 10, fontFamily: "var(--font-mono)", letterSpacing: 1,
                cursor: "pointer", border: `1px solid ${copied ? "var(--green)" : "var(--border2)"}`,
                borderRadius: 5, background: "transparent",
                color: copied ? "var(--green)" : "var(--text-muted)", transition: "all 0.2s",
              }}>{copied ? "✓ COPIED" : "⎘ COPY ALL"}</button>
            )}
          </div>

          <div style={{ flex: 1, overflowY: "auto", padding: "22px 26px" }}>

            {/* EMPTY */}
            {!output && step === 0 && (
              <div style={{ height: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 16, textAlign: "center", opacity: 0.3 }}>
                <div style={{ fontSize: 44 }}>◈</div>
                <div style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 20, color: "#888" }}>Awaiting your vision</div>
                <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "#555", lineHeight: 2 }}>
                  Upload an image → Gemini extracts all visual data<br />
                  Add intention → Claude architects the prompt<br />
                  Copy → Paste into your AI tool
                </div>
              </div>
            )}

            {/* LOADING */}
            {isLoading && !output && (
              <div style={{ height: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 20 }}>
                <div style={{ fontSize: 36, animation: "pulse 1.2s infinite" }}>◈</div>
                <div style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 18, color: "#555" }}>
                  {step === 1 ? "Gemini is reading your image..." : "Claude is architecting your prompt..."}
                </div>
                <div style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "#333", letterSpacing: 1 }}>
                  {step === 1 ? "Extracting colors · materials · lighting · composition" : "Fusing visual data with $1M schema"}
                </div>
              </div>
            )}

            {/* OUTPUT */}
            {output && (
              <div style={{ display: "flex", flexDirection: "column", gap: 18, animation: "fadeUp 0.4s ease" }}>

                {/* Quality */}
                <div style={{ display: "flex", alignItems: "center", gap: 14, padding: "11px 16px", background: "var(--surface)", borderRadius: 8, border: "1px solid var(--border)" }}>
                  <span style={{ fontFamily: "var(--font-mono)", fontSize: 9, letterSpacing: 2.5, textTransform: "uppercase", color: "var(--text-dim)", whiteSpace: "nowrap" }}>Prompt Quality</span>
                  <div style={{ flex: 1, height: 3, background: "var(--border)", borderRadius: 2, overflow: "hidden" }}>
                    <div style={{ width: `${qScore}%`, height: "100%", background: qColor, borderRadius: 2, transition: "width 1.2s ease" }} />
                  </div>
                  <span style={{ fontFamily: "var(--font-mono)", fontSize: 14, fontWeight: 500, color: qColor, minWidth: 48, textAlign: "right" }}>{qScore}/100</span>
                </div>

                {/* Ghost Director */}
                {output.ghost_director && (
                  <div style={{ padding: "12px 16px", background: "rgba(255,77,0,0.03)", border: "1px solid rgba(255,77,0,0.1)", borderRadius: 8, fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 13.5, color: "#666", lineHeight: 1.7 }}>
                    "{output.ghost_director}"
                  </div>
                )}

                {/* TAB: PROMPT */}
                {activeTab === "prompt" && (
                  <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                    <div><SectionLabel color="var(--accent)">Main Prompt</SectionLabel><PromptBox content={output.main_prompt} borderColor="var(--accent)" /></div>
                    <div><SectionLabel color="#ff6464">Negative Prompt</SectionLabel><PromptBox content={output.negative_prompt} borderColor="#ff6464" textColor="#ff9999" /></div>
                  </div>
                )}

                {/* TAB: LAYERS */}
                {activeTab === "layers" && output.layers && (
                  <div>
                    <SectionLabel color="var(--gold)">Layer Breakdown</SectionLabel>
                    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                      {Object.entries(output.layers).map(([k, v]) => v && (
                        <div key={k} style={{ display: "grid", gridTemplateColumns: "95px 1fr", gap: 10, alignItems: "start" }}>
                          <span style={{ fontFamily: "var(--font-mono)", fontSize: 9, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: 1.5, paddingTop: 6 }}>{k}</span>
                          <span style={{ fontFamily: "var(--font-mono)", fontSize: 12, color: "#c8c4be", background: "var(--surface)", borderRadius: 5, padding: "6px 10px", border: "1px solid var(--border)", lineHeight: 1.6 }}>{v}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* TAB: TOOLS */}
                {activeTab === "tools" && (
                  <div>
                    <SectionLabel color="var(--green)">Tool Recommendations</SectionLabel>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
                      {tools.map(tool => {
                        const isRec = output.recommended_tool && tool.name.toLowerCase().includes(output.recommended_tool.toLowerCase().split(" ")[0]);
                        return (
                          <div key={tool.name} style={{
                            background: isRec ? "rgba(74,222,128,0.04)" : "var(--surface)",
                            border: `1px solid ${isRec ? "var(--green)" : "var(--border)"}`,
                            borderRadius: 8, padding: "12px 10px", textAlign: "center",
                          }}>
                            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 5 }}>{tool.name}</div>
                            <div style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--text-muted)", lineHeight: 1.5 }}>{tool.use}</div>
                            {isRec && <div style={{ display: "inline-block", marginTop: 7, fontSize: 8, padding: "2px 8px", background: "rgba(74,222,128,0.12)", color: "var(--green)", borderRadius: 2, fontFamily: "var(--font-mono)", letterSpacing: 1.5 }}>BEST MATCH</div>}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* TAB: RAW ANALYSIS */}
                {activeTab === "analysis" && (
                  geminiAnalysis ? (
                    <div>
                      <SectionLabel color="var(--blue)">Gemini Vision Raw Data</SectionLabel>
                      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                        {Object.entries(geminiAnalysis).map(([k, v]) => (
                          <div key={k} style={{ display: "grid", gridTemplateColumns: "95px 1fr", gap: 10, alignItems: "start" }}>
                            <span style={{ fontFamily: "var(--font-mono)", fontSize: 9, color: "var(--blue)", textTransform: "uppercase", letterSpacing: 1.5, paddingTop: 6 }}>{k}</span>
                            <span style={{ fontFamily: "var(--font-mono)", fontSize: 12, color: "#888", background: "rgba(66,133,244,0.04)", borderRadius: 5, padding: "6px 10px", border: "1px solid rgba(66,133,244,0.1)", lineHeight: 1.6 }}>{v}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--text-dim)", textAlign: "center", paddingTop: 60 }}>
                      No image uploaded — no Gemini analysis available.
                    </div>
                  )
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
