export const LIBRARY = {
  style: [
    "Cinematic", "Documentary", "Luxury Commercial", "Editorial",
    "Noir", "Hyperrealist", "Minimalist", "Vintage 35mm",
    "Futuristic", "Brutalist",
  ],
  mood: [
    "Intimate", "Dramatic", "Melancholic", "Mysterious",
    "Serene", "Tense", "Nostalgic", "Raw",
    "Triumphant", "Ethereal",
  ],
  tech: [
    "ARRI Alexa", "Anamorphic 2.39:1", "Macro Lens", "Handheld",
    "Slow Motion", "Drone Shot", "Single Light Source",
    "Natural Light", "Speed Ramp", "Rack Focus",
  ],
};

export const VIDEO_TOOLS = [
  { name: "Kling 2.x",     use: "Organic motion & realism" },
  { name: "Runway Gen-4",  use: "Camera movement & transitions" },
  { name: "Sora",          use: "Atmospheric & environmental" },
  { name: "Pika 2.x",      use: "Product & still-life animation" },
  { name: "Luma Dream",    use: "Abstract & stylized looks" },
  { name: "Haiper",        use: "Fast-paced dynamic content" },
];

export const IMAGE_TOOLS = [
  { name: "Midjourney v7",     use: "Artistic & stylized imagery" },
  { name: "Flux Pro 1.1",      use: "Photorealism & product shots" },
  { name: "DALL-E 3",          use: "Prompt adherence & concepts" },
  { name: "Stable Diffusion",  use: "Customization & control" },
  { name: "Ideogram 2",        use: "Text-in-image & typography" },
  { name: "Adobe Firefly",     use: "Commercial-safe outputs" },
];

export type Mode = "video" | "image";
export type Step = 0 | 1 | 2 | 3;

export interface GeminiAnalysis {
  subject: string;
  colors: string;
  materials: string;
  lighting: string;
  composition: string;
  mood: string;
  background: string;
  details: string;
  style: string;
  technical: string;
}

export interface PromptOutput {
  quality_score: number;
  main_prompt: string;
  negative_prompt: string;
  layers: {
    world?: string;
    subject?: string;
    motion?: string;
    lighting?: string;
    lens?: string;
    color?: string;
    intention?: string;
  };
  recommended_tool: string;
  ghost_director: string;
}
